# npm-setup

To install all NPM scripts - run
```
npm i
```


To get "dist" folder start with building all your files:
```
npm run build
```

Watch all files with
```
npm run watch
```
